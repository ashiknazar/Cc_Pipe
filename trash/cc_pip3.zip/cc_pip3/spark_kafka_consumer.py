from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StructType, StringType, DoubleType

# Spark session
spark = (
    SparkSession.builder
    .appName("KafkaToHDFS")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("WARN")

# Schema for Kafka messages
schema = StructType() \
    .add("asset", StringType()) \
    .add("price", DoubleType()) \
    .add("timestamp", StringType())

# Read from Kafka
df = (
    spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", "localhost:9092")
    .option("subscribe", "crypto_prices")
    .option("startingOffsets", "latest")
    .load()
)

# Parse JSON
parsed = (
    df.selectExpr("CAST(value AS STRING) AS json")
      .select(from_json(col("json"), schema).alias("data"))
      .select("data.*")
)

# Write to HDFS with explicit host:port
HDFS_URI = "hdfs://localhost:8020"  # change 'localhost' if your NameNode is remote

query = (
    parsed.writeStream
    .format("parquet")
    .option("path", f"{HDFS_URI}/crypto/prices")
    .option("checkpointLocation", f"{HDFS_URI}/crypto/checkpoints")
    .outputMode("append")
    .start()
)

query.awaitTermination()
